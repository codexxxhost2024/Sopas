"use client"

import { usePreventZoom } from "@/hooks/use-prevent-zoom"

export function ZoomPrevention() {
  usePreventZoom()
  return null
}

